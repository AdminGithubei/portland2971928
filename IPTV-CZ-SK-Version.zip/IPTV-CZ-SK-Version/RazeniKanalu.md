<h1>Řazení kanálů (není kompletní)</h1>

*zahrnuty i kanály, které nejsou součástí aktuální programové nabídky - jejich pozice se bude řídit tímto souborem*

<h2>České řazení</h2>

| pozice   | kanál        | logo       |
|:--------:|:------------:|:----------:|
| 1   | ČT1 HD     | <img height="20" src="https://i.imgur.com/qBlEbN3.png"/> |
| 2   | ČT2 HD     | <img height="20" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/ct2.png"/> |
| 3   | ČT24 HD     | <img height="20" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/ct24.png"/> |
| 4   | ČT sport HD     | <img height="20" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/ct-sport.png"/> |
| 5   | ČT :D/art HD     | <img height="20" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/ct-d.png"/> <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/%C4%8CT_Art_logo.svg/800px-%C4%8CT_Art_logo.svg.png"/> |
| 6   | Nova HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/nova.png"/> |
| 7   | Nova Cinema HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/nova-cinema.png"/> |
| 8   | Nova Action HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/nova-action.png"/> |
| 9   | Nova Fun HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/nova-2-2.png"/> |
| 10   | Nova Gold HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/nova-gold.png"/> |
| 11   | Nova Lady HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/nova-lady.png"/> |
| 12   | Nova Sport 1 HD     | <img height="30" src="https://nova-ott-images-tn.ssl.cdn.cra.cz/r793x357/66798f44-eb1a-4d3a-978e-bc8b61002960"/> |
| 13   | Nova Sport 2 HD     | <img height="30" src="https://nova-ott-images-tn.ssl.cdn.cra.cz/r793x357/85dde7ee-785f-4c1e-94ae-544682f3044d"/> |
| 14   | Nova Sport 3 HD     | <img height="30" src="https://nova-ott-images-tn.ssl.cdn.cra.cz/r793x357/831c96ba-3854-45a7-ab02-f4b3268a836b"/> |
| 15   | Nova Sport 4 HD     | <img height="30" src="https://nova-ott-images-tn.ssl.cdn.cra.cz/r793x357/44d266e4-fbe9-41c0-9328-13ecfdc2132e"/> |
| 16   | Nova Sport 5 HD     | <img height="30" src="https://nova-ott-images-tn.ssl.cdn.cra.cz/r793x357/071e3d03-9f05-4c71-a3ee-c9e2aa6cd937"/> |
| 17   | Nova Sport 6 HD     | <img height="30" src="https://nova-ott-images-tn.ssl.cdn.cra.cz/r793x357/0e4a1682-93e8-480f-ac01-eb985076d110"/> |
| 18   | Markíza International   | <img height="40" src="https://static.wikia.nocookie.net/logopedia/images/3/35/Mark%C3%ADza_International_%282022%29.svg/revision/latest/scale-to-width-down/250?cb=20220811"/> |
| 19   | Prima HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/prima.png"/> |
| 20   | Prima Cool HD     | <img height="30" src="https://upload.wikimedia.org/wikipedia/commons/5/50/Prima_Cool_logo_zelen%C3%A9.png"/> |
| 21   | Prima Love HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/prima-love.png"/> |
| 22   | Prima Zoom HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/prima-zoom.png"/> |
| 23   | Prima Max HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/prima-max.png"/> |
| 24   | Prima Krimi HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/prima-krimi.png"/> |
| 25   | Prima Star HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/prima-star.png"/> |
| 26   | Prima Show HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/prima-show.png"/> |
| 27   | CNN Prima News HD     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/cnn-prima-3.png"/> |
| 28   | Paramount Network    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/prima-comedy-2.png"/> |
| 29   | Seznam.cz TV     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/seznam.png"/> |
| 30   | RELAX     | <img height="30" src="https://upload.wikimedia.org/wikipedia/commons/a/a1/Relax_logo.png"/> |
| 31   | A11     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/a11.png"/> |
| 32   | TV Barrandov     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/barrandov.png"/> |
| 33   | Kino Barrandov     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/kino-barrandov.png"/> |
| 34   | Barrandov Krimi     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/barrandov-krimi.png"/> |
| 35   | Premier Sport 1     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/premier-sport-2.png"/> |
| 36   | Premier Sport 2    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/premier-sport-2.png"/> |
| 37   | Premier Sport 3     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/premier-sport-2.png"/> |
| 38   | Premier Sport 4     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/premier-sport-2.png"/> |
| 38   | Premier Sport 4 Extra     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/premier-sport-2.png"/> |
| 40   | CANAL+ Sport     | <img height="30" src="https://www.canalplussport.cz/doc/cm_tvkanal_img/canal-sport-24.png"/> |
| 41   | CANAL+ Sport 2     | <img height="30" src="https://www.canalplussport.cz/doc/cm_tvkanal_img/canal-sport-2-25.png"/> |
| 42   | Eurosport 1     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/eurosport.png"/> |
| 43   | Eurosport 2     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/eurosport.png"/> |
| 44   | Eurosport 4K CZ     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/eurosport.png"/> |
| 45   | Golf Channel     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/golf.png"/> |
| 46   | Sporty TV     | <img height="30" src="https://www.sportytv.cz/assets/favicon/apple-touch-icon.png"/> |
| 47   | Nickelodeon    | <img height="30" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Nickelodeon_2023_logo_%28outline%29.svg/500px-Nickelodeon_2023_logo_%28outline%29.svg.png"/> |
| 48   | Nick Jr.     | <img height="30" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Nick_Jr._logo_2023_%28outline%29.svg/1200px-Nick_Jr._logo_2023_%28outline%29.svg.png"/> |
| 49   | Nicktoons     | <img height="30" src="https://upload.wikimedia.org/wikipedia/commons/4/4a/Nicktoons_2023_Outlined_Logo.png"/> |
| 50   | Minimax     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/minimax.png"/> |
| 51   | JimJam     | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/jim-jam.png"/> |
| 52   | Disney Channel    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/disney-2.png"/> |
| 53   | LALA TV    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/lala.png"/> |
| 54   | CS Film/Horror    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/cs-film-2.png"/> <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/cs-horror.png"/> |
| 55   | CS Mystery    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/cs-mystery.png"/> |
| 56   | CS History    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/cs-history.png"/> |
| 57   | JOJ Family    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/joj.png"/> |
| 58   | JOJ Cinema    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/joj-cinema.png"/> |
| 59   | HBO    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/hbo.png"/> |
| 60   | HBO 2    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/hbo-2.png"/> |
| 61   | HBO 3    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/hbo-3.png"/> |
| 62   | Filmbox    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/filmbox.png"/> |
| 63   | Filmbox Premium    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/filmbox-premium.png"/> |
| 64   | Filmbox Extra    | <img height="30" src="https://c.sledujfilmbox.cz/files/epg/tv/182.png"/> |
| 65   | Filmbox Stars    | <img height="30" src="https://c.sledujfilmbox.cz/files/epg/tv/76.png"/> |
| 66   | Filmbox Family    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/filmbox-family.png"/> |
| 67   | Filmbox Arthouse    | <img height="30" src="https://c.sledujfilmbox.cz/files/epg/tv/982.png"/> |
| 64   | Docubox    | <img height="30" src="https://c.sledujfilmbox.cz/files/epg/tv/733.png"/> |
| 65   | Fightbox    | <img height="30" src="https://c.sledujfilmbox.cz/files/epg/tv/590.png"/> |
| 66   | Fashionbox    | <img height="30" src="https://c.sledujfilmbox.cz/files/epg/tv/734.png"/> |
| 67   | Fast&Fun Box    | <img height="30" src="https://c.sledujfilmbox.cz/files/epg/tv/983.png"/> |
| 68   | AMC    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/amc.png"/> |
| 69   | Film+    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/film-plus-2.png"/> |
| 70   | Cinemax    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/cinemax.png"/> |
| 71   | Cinemax 2    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/cinemax-2.png"/> |
| 72   | AXN    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/axn.png"/> |
| 73   | Film Europe    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/film-europe.png"/> |
| 74   | Film Europe +    | <img height="30" src="https://www.kukitv.sk/media/media_img/logo_filmeurope22.png"/> |
| 75   | Epic Drama    | <img height="30" src="https://telly.cz/wp-content/themes/telly/dist/images/channel/epic-drama.png"/> |
| 76   | Story4    | <img height="30" src="https://static.wikia.nocookie.net/tvfanon6528/images/9/91/Story_4_%282018-.n.v.%29.png/revision/latest?cb=20200223081150"/> |
| -   | iVysílání Extra HD     | <img height="15" src="https://ctfs.ceskatelevize.cz/static/v8.7/assets/images/ivysilani.40364905e6d8c597d722605b08a95b0d.svg"/> <img height="15" src="https://ctfs.ceskatelevize.cz/static/channels/ctsportextra.svg"/> <img height="15" src="https://ctfs.ceskatelevize.cz/static/channels/ct24plus.svg"/> |
